repo: medhu0505/quantum-ascent
branch: main

## Last sync
date: 2026-09-27T15:36:24Z

### Updated in this project
- Mobile web app design built on the crossroads / signboard navigation idea
- Tokens, fonts and scene imagery copied from the repo
- Register flow rebuilt as a four-step mobile form with the repo's validation copy

## Screen map
| Screen | Repo files |
| --- | --- |
| Quantum Mobile.dc.html — Street (hub) | src/components/Hub.tsx, src/data/quantum.ts (scenes), src/styles.css (.sign-*) |
| Quantum Mobile.dc.html — Events | src/components/interiors/EventsInterior.tsx, src/components/interiors/InteriorShell.tsx |
| Quantum Mobile.dc.html — Register | src/components/register/RegisterFormBody.tsx, src/styles.css (.field, .event-pick) |
| Quantum Mobile.dc.html — Team | src/components/interiors/TeamInterior.tsx |
| Quantum Mobile.dc.html — Resources (FAQ/About/Contact) | src/components/interiors/ResourcesInterior.tsx, src/data/quantum.ts |
| Quantum Mobile.dc.html — Menu | src/components/site/MobileMenu.tsx, src/components/site/Bits.tsx |
